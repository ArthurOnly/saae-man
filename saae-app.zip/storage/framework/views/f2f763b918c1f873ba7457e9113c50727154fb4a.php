<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
   <meta charset="UTF-8" />
   <meta name="viewport" content="width=device-width, initial-scale=1.0" />
   <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">

    <title>APP</title>
</head>

<body class="bg-gray-800 text-white">
    <?php if (isset($component)) { $__componentOriginal0fbbf07d0e764cb0eaf83a9205275a16ee002a1b = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Site\Nav::class, []); ?>
<?php $component->withName('site.nav'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal0fbbf07d0e764cb0eaf83a9205275a16ee002a1b)): ?>
<?php $component = $__componentOriginal0fbbf07d0e764cb0eaf83a9205275a16ee002a1b; ?>
<?php unset($__componentOriginal0fbbf07d0e764cb0eaf83a9205275a16ee002a1b); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
    <?php echo $__env->yieldContent('body'); ?>
    <?php echo $__env->yieldContent('js'); ?>
</body>
</html>
<?php /**PATH C:\Users\arthu\Desktop\Programação\saaeMaps\saae-app\resources\views\template.blade.php ENDPATH**/ ?>