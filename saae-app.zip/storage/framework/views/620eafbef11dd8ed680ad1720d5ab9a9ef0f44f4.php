

<?php $__env->startSection('body'); ?>
    <main class="h-screen w-screen flex flex-col">
        <section class="h-1/2 w-full p-12 lg:h-full lg:w-1/2">
            <h1 class="text-5xl font-bold">Sistema de controle SAAE</h1>
        </section>
        <section class="h-1/2 w-full lg:h-full lg:w-1/2">
            <div class="d-flex flex-col p-12 w-full max-w-4xl">
                <a class="bg-blue-800 p-4 w-full block" href=<?php echo e(route("login")); ?>>Entrar como funcionário</a>
                <a class="bg-blue-800 p-4 w-full mt-8 block" href=<?php echo e(route("cliente.cadastrar")); ?>>Cadastrar cliente</a>
            </div>
        </section>
    </main>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\arthu\Desktop\Programação\saaeMaps\saae-app\resources\views/index.blade.php ENDPATH**/ ?>