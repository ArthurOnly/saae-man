<?php $__env->startSection('body'); ?>
    <div id='map' style='width: 100%; height: 500px;'></div>
    <div class="container mx-auto py-24">
        <div class="flex w-full">
            <h1 class="text-4xl font-bold">Procedimentos</h1>
            <?php if($userType == 1): ?>
                <a href="<?php echo e(route('operation.register')); ?>" class="ml-auto px-6 py-3 font-semibold rounded-full bg-green-100 text-green-800">+ Inserir novo</a>
            <?php endif; ?>
        </div>
        <table class="mt-8 min-w-full divide-y divide-gray-200">
            <thead class="bg-gray-700">
                <tr>
                    <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-100 uppercase tracking-wider hidden md:flex">Código</th>
                    <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-100 uppercase tracking-wider">O. de serviço</th>
                    <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-100 uppercase tracking-wider">Endereço</th>
                    <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-100 uppercase tracking-wider">Tipo</th>
                    <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-100 uppercase tracking-wider">Status</th>
                    <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-100 uppercase tracking-wider">Ações</th>
                </tr>
            <thead>
            <?php if(isset($message)): ?>
                <p>Sim</p>
            <?php endif; ?>
            <tbody class="bg-gray-600 divide-y divide-gray-600 w-full">
                <?php $__currentLoopData = $all_operations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $operation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td scope="col" class="px-6 py-4 whitespace-nowrap hidden md:flex">
                            <?php echo e($operation['subscription']); ?>

                        </td>
                        <td scope="col" class="px-6 py-4 whitespace-nowrap">
                            <?php echo e($operation['order']); ?>

                        </td>
                        <td class="px-6 py-4">
                            <?php echo e($operation['address']); ?>

                        </td>
                        <td class="px-6 py-4">
                            <?php echo e($operation['operation_type']["name"]); ?>

                        </td>
                        <td class="px-6 py-4 whitespace-nowrap">
                            <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full <?php echo e($operation['completed'] ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'); ?>">
                            <?php echo e($operation['completed'] ? 'Finalizado' : 'A Realizar'); ?>

                        </span>
                        </td>
                        <td class="px-6 py-4">
                            <a href=<?php echo e(route("operation.finish", $operation['id'])); ?>>Finalizar</a>
                            <?php if($userType == 1): ?>
                                <a class="ml-4" href=<?php echo e(route("operation.register", $operation['id'])); ?>>Editar</a>
                                <a class="ml-4" href=<?php echo e(route("operation.archive", $operation['id'])); ?>>Arquivar</a>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <tbody>
        <table>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script src='https://api.mapbox.com/mapbox-gl-js/v2.3.1/mapbox-gl.js'></script>
    <link href='https://api.mapbox.com/mapbox-gl-js/v2.3.1/mapbox-gl.css' rel='stylesheet' />
    <script>
        function createPopup(text){
            // create the popup
            let popup = new mapboxgl.Popup({className: "text-black", offset: 25 }).setHTML(text);
                    
            // create DOM element for the marker
            let el = document.createElement('div');
            el.id = 'marker';

            return popup;
        }

        function createMarker(map, lat, long, color, popup){
            var marker = new mapboxgl.Marker({
                color: color,
                draggable: true
            }).setLngLat([long, lat]).setPopup(popup)
            .addTo(map);
        }
    </script>
    <script>
        mapboxgl.accessToken = 'pk.eyJ1IjoiYXJ0aHVybWVkIiwiYSI6ImNrcmdvcHdjcjY4ZWUydm1uMGJla2c4a3MifQ.stihOlV05rOjNTYnQGjHnQ';
        var map = new mapboxgl.Map({
            container: 'map', // container ID
            style: 'mapbox://styles/mapbox/streets-v11', // style URL
            center: [-35.42522, -5.64068], // starting position [lng, lat]
            zoom: 13 // starting zoom
        });

        const markers = JSON.parse(('<?php echo htmlspecialchars(json_encode($all_operations), ENT_QUOTES, 'UTF-8'); ?>'.replace(/&quot;/g,'"')));
        markers.map(marker => {
            const baseUrl = "<?php echo url('operation/finish/'); ?>"
            const mapsUrl = `https://www.google.com/maps?q=${marker.lat},${marker.long}`
            const text = `${marker.order} <br> Maps:<a href="${mapsUrl}">Clique aqui</a> <br> <a href="${baseUrl}/${marker.id}">Clique para finalizar</a>\n`
            const popup = createPopup(text);
            const color = marker.completed ? "green" : "red";
            createMarker(map, marker.lat, marker.long, color, popup)
        })
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\arthu\Desktop\Programação\saaeMaps\saae-app\resources\views/dashboard.blade.php ENDPATH**/ ?>