

<?php $__env->startSection('body'); ?>
    <div class="container mx-auto py-24 px-8 max-w-lg">
        <h1 class="text-4xl text-bold">Registrar cliente</h1>
        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>
        <form method="POST" action="" class="mt-8 flex flex-col gap-8">
            <?php echo csrf_field(); ?>
            <div class="flex flex-col gap-4">
                <label>Nome:</label>
                <input value="<?php echo e(old('name')); ?>" required class="text-black" type="text" name="name">
            </div>
            <div class="flex flex-col gap-4">
                <label>Telefone (sem pontos e traços DDXXXXXYYYY):</label>
                <input value="<?php echo e(old('phone')); ?>" required class="text-black" type="text" name="phone">
            </div>
            <div class="flex flex-col gap-4">
                <label>Inscrição:</label>
                <input value="<?php echo e(old('subscription')); ?>" required class="text-black" type="text" name="subscription">
            </div>

            <button type="submit" class="bg-blue-800 p-4">Cadastrar</button>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\arthu\Desktop\Programação\saaeMaps\saae-app\resources\views/clients/cadastro-cliente-fatura.blade.php ENDPATH**/ ?>